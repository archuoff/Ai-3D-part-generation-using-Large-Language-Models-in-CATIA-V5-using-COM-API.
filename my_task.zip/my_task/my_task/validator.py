# -- coding: utf-8 --
"""
ai_cad_pipeline.py
------------------------------------------
TEXT → LLM Parsing → JSON Feature Tree → LGM Validator + Design Rules
------------------------------------------
Future: Replace LGM_Validator with ML-driven geometric validator
"""
import json, re, requests, sys, os, math

# ================== 1. CONFIG ==================
OLLAMA_URL = "http://localhost:11434/api/generate"
MODEL = "llama3.1:latest"

SYSTEM_PROMPT = """
You are a CAD design assistant.
Convert the text requirement into a structured Feature Tree JSON.

Schema:
{
  "part": "string",
  "features": [
    {"type": "string", "parameters": "varies by feature"}
  ]
}

Rules:
- JSON only (no markdown or explanation)
- Use mm units
- Use {"type":"center"} for centered holes
- Use {"type":"xy","x":<mm>,"y":<mm>} for given positions
- Only include real, logical features
"""

# ================== 2. LLM PARSING ==================
def call_llm(user_prompt: str) -> str:
    payload = {
        "model": MODEL,
        "prompt": SYSTEM_PROMPT + "\nUser prompt:\n" + user_prompt + "\nJSON:",
        "format": "json",
        "stream": False
    }
    try:
        response = requests.post(OLLAMA_URL, json=payload, timeout=180)
        response.raise_for_status()
    except requests.RequestException as e:
        print(f"❌ LLM request failed: {e}")
        sys.exit(1)

    env = response.json()
    raw_text = (env.get("response") or "").strip()

    os.makedirs("sample_output", exist_ok=True)
    with open("sample_output/last_raw_llm.txt", "w", encoding="utf-8") as f:
        f.write(raw_text)

    return raw_text


def extract_json(raw_text: str) -> dict:
    try:
        return json.loads(raw_text)
    except json.JSONDecodeError:
        match = re.search(r"\{(?:[^{}]|(?R))*\}", raw_text, re.DOTALL)
        if not match:
            print("❌ No JSON found.")
            print(raw_text[:500])
            sys.exit(1)
        try:
            return json.loads(match.group(0))
        except json.JSONDecodeError as e:
            print("❌ JSON parse error:", e)
            sys.exit(1)

# ================== 3. SEMANTIC MAPPING ==================
def build_feature_tree(parsed_json: dict) -> dict:
    part = parsed_json.get("part", "unknown")
    features = parsed_json.get("features", [])
    tree = {"part": part, "units": "mm", "features": []}

    for f in features:
        ftype = f.get("type")
        params = f.copy()

        if ftype == "sketch_rectangle":
            tree["features"].append({
                "op": "sketch",
                "plane": "XY",
                "geometry": [{"shape": "rectangle", "params": params}]
            })

        elif ftype == "extrude":
            tree["features"].append({
                "op": "pad",
                "thickness": params.get("thickness")
            })

        elif ftype == "hole":
            tree["features"].append({
                "op": "hole",
                "diameter": params.get("diameter"),
                "position": params.get("position", {"type": "center"})
            })

        else:
            tree["features"].append({"op": ftype, "params": params})

    return tree

# ================== 4. LGM VALIDATOR (Phase-2) ==================
def lgm_validate(feature_tree: dict):
    """
    Rule-based LGM Validator.
    Future: Replace with ML geometric reasoning model.
    """

    rules_report = []
    calcs = {}
    corrected_tree = feature_tree.copy()

    # Extract geometry basics
    length = width = thickness = None
    for f in feature_tree["features"]:
        if f["op"] == "sketch":
            g = f["geometry"][0]["params"]
            length, width = g.get("length", 0), g.get("width", 0)
        if f["op"] == "pad":
            thickness = f.get("thickness", 0)

    # --- Rule 1: Minimum thickness ---
    MIN_THICKNESS = 5.0
    if thickness and thickness < MIN_THICKNESS:
        rules_report.append({
            "rule": "Min Thickness",
            "status": "Auto-fixed",
            "old_value": thickness,
            "new_value": MIN_THICKNESS
        })
        for f in corrected_tree["features"]:
            if f["op"] == "pad":
                f["thickness"] = MIN_THICKNESS
    else:
        rules_report.append({
            "rule": "Min Thickness",
            "status": "Pass",
            "value": thickness
        })

    # --- Rule 2: Hole edge clearance (>= 2 × diameter) ---
    EDGE_FACTOR = 2.0
    for f in corrected_tree["features"]:
        if f["op"] == "hole":
            dia = f.get("diameter", 0)
            pos = f.get("position", {"type": "center"})
            if pos["type"] == "xy" and length and width:
                x, y = pos["x"], pos["y"]
                min_edge = EDGE_FACTOR * dia
                fix = False
                if x < min_edge: x, fix = min_edge, True
                if y < min_edge: y, fix = min_edge, True
                if x > length - min_edge: x, fix = length - min_edge, True
                if y > width - min_edge: y, fix = width - min_edge, True
                if fix:
                    f["position"] = {"type": "xy", "x": x, "y": y}
                    rules_report.append({
                        "rule": "Hole Edge ≥ 2×Dia",
                        "status": "Auto-fixed",
                        "new_position": [x, y]
                    })
                else:
                    rules_report.append({
                        "rule": "Hole Edge ≥ 2xDia",
                        "status": "Pass"
                    })
            else:
                rules_report.append({
                    "rule": "Hole Edge ≥ 2xDia",
                    "status": "Center - Pass"
                })

    # --- Rule 3: Aspect ratio (L/W < 5:1 preferred) ---
    if length and width:
        ratio = length / width if width else 0
        status = "Pass" if ratio <= 5 else "Warning"
        rules_report.append({
            "rule": "Aspect Ratio (L/W <= 5)",
            "status": status,
            "ratio": round(ratio, 2)
        })

    # --- Rule 4: Design Volume & Mass Estimation ---
    if length and width and thickness:
        vol = length * width * thickness  # mm³
        density = 7.85e-3  # g/mm³ for steel
        mass = vol * density
        calcs["volume_mm3"] = vol
        calcs["mass_g"] = round(mass, 2)
        calcs["material"] = "Steel (assumed)"
        rules_report.append({
            "rule": "Volume/Mass Estimation",
            "volume_mm3": vol,
            "mass_g": mass
        })

    return corrected_tree, rules_report, calcs

# ================== 5. SAVE UTILS ==================
def save_json(data, name):
    os.makedirs("sample_output", exist_ok=True)
    path = os.path.join("sample_output", name)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    return path

# ================== 6. MAIN ==================
def main():
    print("=== AI CAD Validator Pipeline ===")
    user_text = input("Enter design requirement: ").strip()
    if not user_text:
        print("❌ Empty input."); sys.exit(1)

    # --- Stage 1: LLM Parsing ---
    print("\n→ Step 1: Calling LLaMA via Ollama...")
    raw = call_llm(user_text)
    parsed = extract_json(raw)

    # --- Stage 2: Feature Tree ---
    print("\n→ Step 2: Building Feature Tree...")
    ft = build_feature_tree(parsed)
    print(json.dumps(ft, indent=2))
    save_json(ft, "raw_feature_tree.json")

    # --- Stage 3: LGM Validation + Guidelines ---
    print("\n→ Step 3: Applying Design Rules and Calculations...")
    validated, rules, calcs = lgm_validate(ft)

    print("\n✅ Validated Feature Tree:")
    print(json.dumps(validated, indent=2))
    print("\n📋 Design Rule Report:")
    print(json.dumps(rules, indent=2))
    print("\n📐 Calculations:")
    print(json.dumps(calcs, indent=2))

    save_json(validated, "validated_feature_tree.json")
    save_json(rules, "design_rules.json")
    save_json(calcs, "design_calcs.json")
    print("\n💾 Outputs saved in 'sample_output' folder.")


if __name__ == "__main__":
    main()