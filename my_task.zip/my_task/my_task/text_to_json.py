# -*- coding: utf-8 -*-
"""
text_to_featuretree.py
------------------------------------------
Text Requirement
    ↓
LLM Parsing (via Ollama)
    ↓
Semantic Mapping → JSON Feature Tree
------------------------------------------
Future step: Pass this Feature Tree to LGM validator (ML model)
"""

import json, re, requests, sys, os

# ================== 1. CONFIG ==================

OLLAMA_URL = "http://localhost:11434/api/generate"
MODEL = "llama3.1:latest"

SYSTEM_PROMPT = """
You are a CAD assistant. Convert the user's text requirement into a structured JSON Feature Tree.

Schema:
{
  "part": "string",
  "features": [
    {"type": "string", "parameters": "varies by feature"}
  ]
}

Rules:
- Output STRICT JSON only, no markdown or text.
- Use mm units.
- If position is 'center', return {"type":"center"}.
- If position given, use {"type":"xy", "x":<mm>, "y":<mm>}.
- Do not invent fields outside schema.
"""

# ================== 2. LLM PARSING ==================

def call_llm(user_prompt: str) -> str:
    """
    Send user text requirement to Ollama (LLaMA model) and get raw response.
    """
    payload = {
        "model": MODEL,
        "prompt": SYSTEM_PROMPT + "\nUser prompt:\n" + user_prompt + "\nJSON:",
        "format": "json",
        "stream": False
    }

    try:
        response = requests.post(OLLAMA_URL, json=payload, timeout=180)
        response.raise_for_status()
    except requests.RequestException as e:
        print(f"❌ LLM connection failed: {e}")
        sys.exit(1)

    env = response.json()
    raw_text = (env.get("response") or "").strip()

    # Save raw model output for debugging
    os.makedirs("sample_output", exist_ok=True)
    with open("sample_output/last_raw_llm.txt", "w", encoding="utf-8") as f:
        f.write(raw_text)

    return raw_text


def extract_json(raw_text: str) -> dict:
    """
    Extract JSON safely from LLM output.
    """
    try:
        return json.loads(raw_text)
    except json.JSONDecodeError:
        match = re.search(r"\{(?:[^{}]|(?R))*\}", raw_text, re.DOTALL)
        if not match:
            print("❌ No JSON found in model output.")
            print(raw_text[:500])
            sys.exit(1)
        try:
            return json.loads(match.group(0))
        except json.JSONDecodeError as e:
            print("❌ JSON parse error:", e)
            sys.exit(1)

# ================== 3. SEMANTIC MAPPING ==================

def build_feature_tree(parsed_json: dict) -> dict:
    """
    Convert parsed JSON (from LLM) into a semantically organized Feature Tree.
    This acts as the Semantic Mapping layer.
    """
    part = parsed_json.get("part", "unknown")
    features = parsed_json.get("features", [])

    tree = {"part": part, "units": "mm", "features": []}

    for f in features:
        ftype = f.get("type")
        params = f.copy()

        if ftype == "sketch_rectangle":
            tree["features"].append({
                "op": "sketch",
                "plane": "XY",
                "geometry": [{"shape": "rectangle", "params": params}]
            })

        elif ftype == "extrude":
            tree["features"].append({
                "op": "pad",
                "thickness": params.get("thickness")
            })

        elif ftype == "hole":
            tree["features"].append({
                "op": "hole",
                "diameter": params.get("diameter"),
                "position": params.get("position", {"type": "center"})
            })

        else:
            # Unknown or unhandled feature
            tree["features"].append({"op": ftype, "params": params})

    return tree

# ================== 4. SAVE / UTILS ==================

def save_output(data, filename):
    os.makedirs("sample_output", exist_ok=True)
    path = os.path.join("sample_output", filename)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    return path


# ================== 5. MAIN EXECUTION ==================

def main():
    print("=== TEXT → JSON Feature Tree Generator ===")

    user_text = input("Enter CAD requirement: ").strip()
    if not user_text:
        print("❌ Empty input. Exiting.")
        sys.exit(1)

    print("\n→ Step 1: Sending to LLaMA (Ollama)...")
    raw_response = call_llm(user_text)

    print("\n→ Step 2: Parsing LLM JSON output...")
    parsed_json = extract_json(raw_response)

    print("\n✅ Parsed JSON Output:")
    print(json.dumps(parsed_json, indent=2))

    print("\n→ Step 3: Building Semantic Feature Tree...")
    feature_tree = build_feature_tree(parsed_json)

    print("\n✅ Final Feature Tree:")
    print(json.dumps(feature_tree, indent=2))

    save_output(feature_tree, "feature_tree.json")
    print("\n💾 Feature tree saved at: sample_output/feature_tree.json")
    print("\nNext step → Pass this JSON to LGM validator ML module for validation & constraints.")


# ================== 6. RUN ==================

if __name__ == "__main__":
    main()
