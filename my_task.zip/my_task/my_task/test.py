# -- coding: utf-8 -
"""
 validator.py  —  Text → LLM JSON → FeatureTree → Rules/Calcs → Files- Works for rectangular plate-like parts with holes.- Forces strict LLM schema; normalizes common synonyms.- Outputs:
    sample_output/raw_feature_tree.json
    sample_output/validated_feature_tree.json
    sample_output/design_rules.json
    sample_output/design_calcs.json
 """
import json, re, requests, sys, os
 # ================== 0. CONFIG ==================
OLLAMA_URL = "http://localhost:11434/api/generate"
MODEL = "llama3.1:latest"
SYSTEM_PROMPT = """
 You are a CAD design assistant. Output STRICT JSON ONLY (no text/markdown).
 Target schema and allowed feature types:
 {
 }
  "part": "string",
  "features": [
    {"type":"sketch_rectangle","length": <mm>, "width": <mm>},
    {"type":"extrude","thickness": <mm>},
    {"type":"hole","diameter": <mm>,
     "position": {"type":"center"} | {"type":"xy","x": <mm>, "y": <mm>}}
  ]
 Rules:- Use mm units.- Use exactly these type names: sketch_rectangle, extrude, hole.- If user says “center hole”, use {"type":"center"}.- If user gives a point, use {"type":"xy","x":...,"y":...}.- Do NOT invent extra fields or feature types.- Return ONLY JSON that matches the schema.
 Example for: plate 100x60x3 with 10mm hole at (15,20)
 {
  "part": "plate",
  "features": [
    {"type":"sketch_rectangle","length":100,"width":60},
    {"type":"extrude","thickness":3},
    {"type":"hole","diameter":10,"position":{"type":"xy","x":15,"y":20}}
  ]
 }
 """
MIN_THICKNESS = 5.0
EDGE_FACTOR   = 2.0
STEEL_DENSITY_G_PER_MM3 = 7.85e-3
def call_llm(user_prompt: str) -> str:
    payload = {
        "model": MODEL,
        "prompt": SYSTEM_PROMPT + "\nUser prompt:\n" + user_prompt + "\nJSON:",
        "format": "json",
        "stream": False
    }
    try:
        r = requests.post(OLLAMA_URL, json=payload, timeout=180)
        r.raise_for_status()
    except requests.RequestException as e:
        print(f"LLM request failed: {e}")
        sys.exit(1)
    env = r.json()
    raw_text = (env.get("response") or "").strip()
    os.makedirs("sample_output", exist_ok=True)
    with open("sample_output/last_raw_llm.txt", "w", encoding="utf-8") as f:
        f.write(raw_text)
    return raw_text
def extract_json(raw_text: str) -> dict:
    try:
        return json.loads(raw_text)
    except json.JSONDecodeError:
        m = re.search(r"\{(?:[^{}]|(?R))*\}", raw_text, re.DOTALL)
        if not m:
            print(" No JSON found in model output.")
            sys.exit(1)
        return json.loads(m.group(0))
def normalize_llm_json(parsed: dict) -> dict:
    feats = []
    for f in parsed.get("features", []):
        t = (f.get("type") or "").lower()
        p = f.get("parameters", f)
        if t in ["plate", "rectangle_plate", "rect_plate"]:
            L = p.get("length"); W = p.get("width"); T = p.get("thickness")
            if L and W: feats.append({"type": "sketch_rectangle", "length": L, "width": W})
            if T: feats.append({"type": "extrude", "thickness": T})
            continue
        if t in ["extrude", "pad"]:
            th = p.get("thickness")
            if th: feats.append({"type": "extrude", "thickness": th})
            continue
        if t in ["hole", "drill_hole", "through_hole"]:
            dia = p.get("diameter")
            pos = p.get("position")
            if dia:
                if not pos and ("x" in p and "y" in p):
                    pos = {"type": "xy", "x": p["x"], "y": p["y"]}
                feats.append({"type": "hole", "diameter": dia, "position": pos or {"type": "center"}})
            continue
        if t in ["sketch_rectangle", "extrude", "hole"]: feats.append(f)
    parsed["features"] = feats
    return parsed
def build_feature_tree(parsed_json: dict) -> dict:
    part = parsed_json.get("part", "unknown")
    features = parsed_json.get("features", [])
    tree = {"part": part, "units": "mm", "features": []}
    for f in features:
        ftype = f.get("type")
        if ftype == "sketch_rectangle":
            tree["features"].append({"op": "sketch","plane": "XY",
                "geometry": [{"shape": "rectangle","params": {"origin": "LL","x0": 0,"y0": 0,
                "length": f.get("length"),"width": f.get("width")}}]})
        elif ftype == "extrude":
            tree["features"].append({"op": "pad","thickness": f.get("thickness")})
        elif ftype == "hole":
            pos = f.get("position", {"type": "center"})
            if isinstance(pos, dict) and pos.get("type") == "xy":
                pos = {"type": "xy","x": float(pos["x"]),"y": float(pos["y"])}
            else: pos = {"type": "center"}
            tree["features"].append({"op": "hole","diameter": f.get("diameter"),"position": pos})
        else:
            tree["features"].append({"op": ftype,"params": f})
    return tree
def lgm_validate(feature_tree: dict):
    rules_report, calcs = [], {}
    corrected_tree = json.loads(json.dumps(feature_tree))
    length = width = thickness = None
    for f in corrected_tree["features"]:
        if f.get("op") == "sketch":
            rect = next((g for g in f.get("geometry", []) if g.get("shape") == "rectangle"), None)
            if rect:
                rp = rect["params"]
                length, width = rp.get("length"), rp.get("width")
        if f.get("op") == "pad":
            thickness = f.get("thickness")
    if thickness and thickness < MIN_THICKNESS:
        rules_report.append({"rule": "Min Thickness","status": "Auto-fixed","old_value": thickness,"new_value": MIN_THICKNESS})
        for f in corrected_tree["features"]:
            if f.get("op") == "pad": f["thickness"] = MIN_THICKNESS
        thickness = MIN_THICKNESS
    else:
        rules_report.append({"rule": "Min Thickness","status": "Pass","value": thickness})
    for f in corrected_tree["features"]:
        if f.get("op") == "hole":
            dia = float(f.get("diameter") or 0)
            pos = f.get("position", {"type": "center"})
            if pos.get("type") == "xy" and length and width:
                x, y = float(pos["x"]), float(pos["y"])
                min_edge = EDGE_FACTOR * dia
                fix = False
                if x < min_edge: x, fix = min_edge, True
                if y < min_edge: y, fix = min_edge, True
                if x > (length - min_edge): x, fix = (length - min_edge), True
                if y > (width - min_edge): y, fix = (width - min_edge), True
                if fix:
                    f["position"] = {"type": "xy","x": x,"y": y}
                    rules_report.append({"rule": "Hole Edge ≥ 2×Dia","status": "Auto-fixed","new_position": [x, y]})
                else:
                    rules_report.append({"rule": "Hole Edge ≥ 2×Dia","status": "Pass"})
            else:
                rules_report.append({"rule": "Hole Edge ≥ 2×Dia","status": "Pass/Center or Unknown base dims"})
    if length and width:
        ratio = float(length) / float(width) if float(width) != 0 else None
        rules_report.append({"rule": "Aspect Ratio (L/W <= 5)","status": "Pass" if (ratio and ratio <= 5.0) else "Warning","ratio": round(ratio, 2) if ratio else None})
    if length and width and thickness:
        vol = float(length) * float(width) * float(thickness)
        mass_g = vol * STEEL_DENSITY_G_PER_MM3
        calcs = {"volume_mm3": vol,"mass_g": round(mass_g, 2),"material": "Steel (assumed)"}
        rules_report.append({"rule": "Volume/Mass Estimation","volume_mm3": vol,"mass_g": mass_g})
    return corrected_tree, rules_report, calcs
def save_json(data, name):
    os.makedirs("sample_output", exist_ok=True)
    path = os.path.join("sample_output", name)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    return path
def main():
    print("=== AI CAD Validator Pipeline (plate + holes) ===")
    user_text = input("Enter design requirement: ").strip()
    if not user_text: print(" Empty input."); sys.exit(1)
    print("\n→ Step 1: Calling LLaMA via Ollama...")
    raw = call_llm(user_text)
    parsed = extract_json(raw)
    parsed = normalize_llm_json(parsed)
    print("\n→ Step 2: Building Feature Tree...")
    ft = build_feature_tree(parsed)
    print(json.dumps(ft, indent=2))
    save_json(ft, "raw_feature_tree.json")
    print("\n→ Step 3: Applying Design Rules and Calculations...")
    validated, rules, calcs = lgm_validate(ft)
    print("\n Validated Feature Tree:")
    print(json.dumps(validated, indent=2))
    print("\n Design Rule Report:")
    print(json.dumps(rules, indent=2))
    print("\n Calculations:")
    print(json.dumps(calcs, indent=2))
    save_json(validated, "validated_feature_tree.json")
    save_json(rules, "design_rules.json")
    save_json(calcs, "design_calcs.json")
    print("\n Outputs saved in 'sample_output' folder.")
if __name__ == "__main__":
    main()