# -*- coding: utf-8 -*-
# app.py
# Prompt -> LLM (Ollama) -> Template intent -> FeatureTree (mini-LGM) -> Constraints -> VBScript

import json, re, sys
import requests

OLLAMA_URL = "http://localhost:11434/api/generate"
MODEL = "llama3:latest"

# ---------------- Templates (you can add more later) ----------------
TEMPLATES = {
    "plate": {
        "required": ["length", "width", "thickness"],
        "optional": ["material", "holes"],  # holes: list of {diameter, position:{type:center|xy,x,y}}
    },
    "l_bracket": {
        "required": ["base_length", "base_width", "vertical_height", "thickness"],
        "optional": ["material", "holes"]
    }
}

# ---------------- LLM: prompt -> template intent --------------------
INTENT_SYSTEM = """
You are a CAD planner that maps user prompts to a parametric TEMPLATE.
Allowed templates: ["plate","l_bracket"].
Return STRICT JSON ONLY, no text, no markdown.

Schema:
{
  "template": "plate" | "l_bracket",
  "params": {
    // for 'plate':
    // length, width, thickness (mm), optional material,
    // optional holes: [{"diameter": <mm>, "position": {"type":"center" | "xy","x":<mm>,"y":<mm>}}]

    // for 'l_bracket':
    // base_length, base_width, vertical_height, thickness (mm), optional holes same as above
  }
}
Rules:
- Use mm units.
- If user mentions holes at center, use {"type":"center"}.
- If not mentioned, omit holes.
- Do not invent fields outside schema.
- JSON ONLY.
"""

def call_ollama_for_intent(user_prompt: str) -> dict:
    payload = {
        "model": MODEL,
        "prompt": INTENT_SYSTEM + "\nUser prompt:\n" + user_prompt + "\nJSON:",
        "format": "json",        # ask for JSON output
        "stream": False          # easier to parse
    }
    try:
        r = requests.post(OLLAMA_URL, json=payload, timeout=180)
        r.raise_for_status()
    except requests.RequestException as e:
        print(f"❌ Ollama request failed: {e}")
        sys.exit(1)

    env = r.json()
    text = (env.get("response") or "").strip()

    # if the model returns plain JSON, parse directly; else try to extract
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        m = re.search(r"\{(?:[^{}]|(?R))*\}", text, re.DOTALL)
        if not m:
            print("❌ LLM did not return JSON:\n", text[:800])
            sys.exit(1)
        try:
            return json.loads(m.group(0))
        except json.JSONDecodeError as e:
            print("❌ JSON parse error:", e, "\nExtracted:\n", m.group(0)[:800])
            sys.exit(1)

# --------------- Build FeatureTree (mini-LGM) from template ----------
def build_feature_tree(intent: dict) -> dict:
    tpl = intent["template"]
    p   = intent["params"]
    if tpl == "plate":
        L = float(p["length"]); W = float(p["width"]); T = float(p["thickness"])
        features = [
            {"op":"sketch","id":"S1","plane":"XY",
             "geometry":[{"shape":"rectangle","params":{"origin":"LL","x0":0,"y0":0,"length":L,"width":W}}]},
            {"op":"pad","id":"P1","from":"S1","thickness":T}
        ]
        holes = p.get("holes") or []
        for i, h in enumerate(holes, start=1):
            pos = h.get("position", {"type":"center"})
            features.append({"op":"hole","id":f"H{i}","on":"P1",
                             "diameter": float(h["diameter"]), "position": pos})
        return {"units":"mm","part":"plate","material": p.get("material"), "features": features}

    if tpl == "l_bracket":
        BL = float(p["base_length"]); BW = float(p["base_width"])
        H  = float(p["vertical_height"]); T = float(p["thickness"])
        # Simplified L-bracket as two pads joined at an edge (same sketch plane for demo)
        features = [
            {"op":"sketch","id":"S1","plane":"XY",
             "geometry":[{"shape":"rectangle","params":{"origin":"LL","x0":0,"y0":0,"length":BL,"width":BW}}]},
            {"op":"pad","id":"P_base","from":"S1","thickness":T},
            {"op":"sketch","id":"S2","plane":"YZ",  # upright leg (simplified)
             "geometry":[{"shape":"rectangle","params":{"origin":"LL","x0":0,"y0":0,"length":BW,"width":H}}]},
            {"op":"pad","id":"P_leg","from":"S2","thickness":T}
        ]
        holes = p.get("holes") or []
        for i, h in enumerate(holes, start=1):
            pos = h.get("position", {"type":"center"})
            features.append({"op":"hole","id":f"H{i}","on":"P_base",
                             "diameter": float(h["diameter"]), "position": pos})
        return {"units":"mm","part":"l_bracket","material": p.get("material"), "features": features}

    print(f"❌ Unknown template: {tpl}")
    sys.exit(1)

# --------------- Constraint & quick calcs -----------------------------
MIN_THICKNESS = 5.0
EDGE_FACTOR   = 2.0  # min edge distance = 2*diameter

def apply_constraints(ft: dict):
    report = {"rules":[], "estimates":{}}
    # get base plate dims if present
    L=W=None
    for f in ft["features"]:
        if f["op"]=="sketch":
            for g in f.get("geometry",[]):
                if g.get("shape")=="rectangle":
                    p = g["params"]; L = p.get("length"); W = p.get("width"); break
            break

    # thickness rule
    for f in ft["features"]:
        if f["op"]=="pad":
            th = float(f["thickness"])
            if th < MIN_THICKNESS:
                report["rules"].append({"rule":"min_thickness","status":"auto_fix","from":th,"to":MIN_THICKNESS})
                f["thickness"] = MIN_THICKNESS
            else:
                report["rules"].append({"rule":"min_thickness","status":"pass","value":th})

    # hole edge distance
    for f in ft["features"]:
        if f["op"]=="hole":
            dia = float(f["diameter"])
            pos = f.get("position", {"type":"center"})
            if pos.get("type")=="xy" and L and W:
                x,y = float(pos["x"]), float(pos["y"])
                min_edge = EDGE_FACTOR * dia
                fix=False
                if x < min_edge: x,fix = min_edge,True
                if y < min_edge: y,fix = min_edge,True
                if x > L-min_edge: x,fix = L-min_edge,True
                if y > W-min_edge: y,fix = W-min_edge,True
                if fix:
                    f["position"] = {"type":"xy","x":x,"y":y}
                    report["rules"].append({"rule":"hole_edge>=2d","status":"auto_fix","new_xy":[x,y]})
                else:
                    report["rules"].append({"rule":"hole_edge>=2d","status":"pass"})
            else:
                report["rules"].append({"rule":"hole_edge>=2d","status":"pass/center"})

    # quick volume estimate if plate-like dims exist
    if L and W:
        th = None
        for f in ft["features"]:
            if f["op"]=="pad":
                th = float(f["thickness"]); break
        if th:
            report["estimates"]["volume_mm3"] = L*W*th

    return ft, report

# --------------- VBScript generator (CATIA) ---------------------------
def to_vbs(ft: dict) -> str:
    vb = []
    vb += [
        "' Auto-generated by AI CAD Agent",
        "Dim CATIA: Set CATIA = GetObject(, \"CATIA.Application\")",
        "Dim partDoc: Set partDoc = CATIA.Documents.Add(\"Part\")",
        "Dim part: Set part = partDoc.Part",
        "Dim shapeFactory: Set shapeFactory = part.ShapeFactory",
        "Dim hbs: Set hbs = part.HybridBodies",
        "Dim hb: Set hb = hbs.Add()",
        "Dim sketches: Set sketches = hb.HybridSketches",
        "Dim XY: Set XY = part.OriginElements.PlaneXY",
        "Dim YZ: Set YZ = part.OriginElements.PlaneYZ",
        ""
    ]

    last_sk = "sk"
    last_pad = "pad"
    L=W=None

    for f in ft["features"]:
        op = f["op"]

        if op=="sketch":
            plane = f.get("plane","XY")
            plane_var = "XY" if plane=="XY" else ("YZ" if plane=="YZ" else "XY")
            vb += [
                "' --- sketch ---",
                f"Dim {last_sk}: Set {last_sk} = sketches.Add({plane_var})",
                "Dim f2d: Set f2d = " + last_sk + ".OpenEdition()"
            ]
            for g in f.get("geometry",[]):
                if g.get("shape")=="rectangle":
                    p = g["params"]
                    x0 = float(p.get("x0",0)); y0 = float(p.get("y0",0))
                    L  = float(p.get("length",100)); W = float(p.get("width",50))
                    x1,y1 = x0+L, y0+W
                    vb.append(f"f2d.CreateRectangle {x0},{y0},{x1},{y1}")
            vb += [last_sk + ".CloseEdition",""]

        elif op=="pad":
            th = float(f["thickness"])
            vb += [
                "' --- pad ---",
                f"Dim {last_pad}",
                f"Set {last_pad} = shapeFactory.AddNewPad({last_sk}, {th})",
                ""
            ]

        elif op=="hole":
            dia = float(f["diameter"])
            pos = f.get("position",{"type":"center"})
            if (pos.get("type")=="center") and L and W:
                x,y = L/2.0, W/2.0
            else:
                x = float(pos.get("x",0)); y = float(pos.get("y",0))
            vb += [
                "' --- hole (simplified) ---",
                "Dim hole",
                f"Set hole = shapeFactory.AddNewHole({x},{y},{dia}, {last_pad})",
                "hole.ThreadingMode = 0",
                ""
            ]

        elif op=="fillet":
            r = float(f.get("radius",2))
            vb += [
                "' --- fillet (placeholder) ---",
                f"' Desired radius: {r}",
                ""
            ]

    vb += ["part.Update",""]
    return "\n".join(vb)

# ------------------------------- main --------------------------------
if __name__ == "__main__":
    user = input("Enter design prompt: ").strip()
    if not user:
        print("❌ Empty prompt."); sys.exit(1)

    print("\n→ LLM: classifying & extracting template params...")
    intent = call_ollama_for_intent(user)
    print("Intent:\n", json.dumps(intent, indent=2))

    tpl = intent.get("template")
    if tpl not in TEMPLATES:
        print(f"❌ Unsupported template: {tpl}")
        sys.exit(1)
    # quick required param check
    missing = [k for k in TEMPLATES[tpl]["required"] if k not in intent.get("params",{})]
    if missing:
        print("❌ Missing required params:", missing)
        sys.exit(1)

    print("\n→ Building FeatureTree (mini-LGM)...")
    ft = build_feature_tree(intent)
    print(json.dumps(ft, indent=2))

    print("\n→ Applying constraints & quick calcs...")
    vft, report = apply_constraints(ft)
    print("Validated FeatureTree:\n", json.dumps(vft, indent=2))
    print("Precheck report:\n", json.dumps(report, indent=2))

    print("\n→ Generating VBScript...")
    vbs = to_vbs(vft)
    with open("generated.vbs","w",encoding="utf-8") as f:
        f.write(vbs)
    print("✅ VBScript written to generated.vbs")
