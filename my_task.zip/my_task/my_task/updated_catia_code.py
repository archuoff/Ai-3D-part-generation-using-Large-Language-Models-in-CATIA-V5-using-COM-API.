# -- coding: utf-8 --
"""
Universal_catia_code.py — robust CATIA macro generator (PartBody + Pad + Pocket)
- Reads:  sample_output/validated_feature_tree.json  (falls back to raw_feature_tree.json)
- Generates: sample_output/generated.CATScript
- Supports: rectangle sketch -> pad (thickness) -> one or many hole pockets
- Hole positioning: {"type":"xy","x","y"} or {"type":"center"} (uses baseL/2, baseW/2)
"""
 
import json, os, sys
 
INPUTS = [
    "sample_output/validated_feature_tree.json",
    "sample_output/raw_feature_tree.json",
    "sample_output/feature_tree.json",
]
 
def load_feature_tree():
    for p in INPUTS:
        if os.path.exists(p):
            with open(p, "r", encoding="utf-8") as f:
                return json.load(f), p
    print("❌ No feature tree JSON found in sample_output/")
    sys.exit(1)
 
def extract_dims_and_features(ft):
    """Return baseL, baseW, thickness, holes=[(hx,hy,dia),...]"""
    baseL = baseW = thickness = None
    holes = []
    # read in-order
    for f in ft.get("features", []):
        op = (f.get("op") or "").lower()
        if op == "sketch":
            rect = next((g for g in f.get("geometry", []) if (g.get("shape") or "").lower()=="rectangle"), None)
            if rect:
                p = rect.get("params", {})
                baseL = float(p.get("length") or 0.0)
                baseW = float(p.get("width")  or 0.0)
        elif op == "pad":
            val = f.get("thickness")
            if val is not None:
                thickness = float(val)
        elif op == "hole":
            dia = float(f.get("diameter") or 0.0)
            pos = f.get("position", {"type":"center"})
            if isinstance(pos, dict) and (pos.get("type") or "").lower() == "xy":
                hx = float(pos.get("x") or 0.0)
                hy = float(pos.get("y") or 0.0)
            else:
                # center -> resolve later if base dims present
                hx = hy = None
            holes.append((hx, hy, dia))
    return baseL, baseW, thickness, holes
 
def vb_escape(val):
    return str(val).replace('"','""')
 
def render_catscript(baseL, baseW, thk, holes):
    # Resolve center positions now that we have baseL/baseW
    resolved_holes = []
    for hx, hy, dia in holes:
        if hx is None or hy is None:
            hx2 = (baseL or 0.0) / 2.0
            hy2 = (baseW or 0.0) / 2.0
            resolved_holes.append((hx2, hy2, dia))
        else:
            resolved_holes.append((hx, hy, dia))
 
    # Build VB macro
    lines = []
    P = lines.append
 
    P("' ==============================================")
    P("' CATIA V5 CATScript — Plate + Pad + Pocket Holes (auto-generated)")
    P("' ==============================================")
    P("Sub CATMain()")
    P("")
    P("  ' ----- Parameters extracted from JSON -----")
    P(f"  Dim baseL, baseW, thk")
    P(f"  baseL = {baseL if baseL is not None else 100}")
    P(f"  baseW = {baseW if baseW is not None else 50}")
    P(f"  thk   = {thk   if thk   is not None else 10}")
    # emit holes array
    P("  ' holes: array of [x, y, dia]")
    if resolved_holes:
        P(f"  Dim holes(" + str(len(resolved_holes)-1) + ", 2)")
        for i,(hx,hy,dia) in enumerate(resolved_holes):
            P(f"  holes({i},0) = {hx}")
            P(f"  holes({i},1) = {hy}")
            P(f"  holes({i},2) = {dia}")
    else:
        P("  Dim holes(-1, 2) ' no holes")
    P("")
    P("  ' Ensure CATIA")
    P("  Dim CATIA")
    P("  On Error Resume Next")
    P("  Set CATIA = GetObject(, \"CATIA.Application\")")
    P("  If Err.Number <> 0 Then")
    P("    Set CATIA = CreateObject(\"CATIA.Application\")")
    P("    Err.Clear")
    P("  End If")
    P("  On Error GoTo 0")
    P("  CATIA.Visible = True")
    P("")
    P("  ' New Part")
    P("  Dim partDocument")
    P("  Set partDocument = CATIA.Documents.Add(\"Part\")")
    P("  Dim part : Set part = partDocument.Part")
    P("  Dim shapeFactory : Set shapeFactory = part.ShapeFactory")
    P("")
    P("  ' ====== Use PartBody (solid body) ======")
    P("  Dim body1")
    P("  On Error Resume Next")
    P("  Set body1 = part.MainBody")
    P("  If body1 Is Nothing Then Set body1 = part.Bodies.Item(\"PartBody\")")
    P("  On Error GoTo 0")
    P("  If body1 Is Nothing Then")
    P("    Set body1 = part.Bodies.Add()")
    P("    body1.Name = \"PartBody\"")
    P("  End If")
    P("  part.InWorkObject = body1")
    P("")
    P("  Dim XY : Set XY = part.OriginElements.PlaneXY")
    P("")
    P("  ' =======================")
    P("  ' 1) SKETCH on PartBody: rectangle (4 lines)")
    P("  ' =======================")
    P("  Dim sketches1 : Set sketches1 = body1.Sketches")
    P("  Dim skRect, f2d")
    P("  Set skRect = sketches1.Add(XY)")
    P("  Set f2d = skRect.OpenEdition()")
    P("")
    P("  Dim x0, y0, x1, y1")
    P("  x0 = 0 : y0 = 0")
    P("  x1 = baseL : y1 = baseW")
    P("")
    P("  Dim L1, L2, L3, L4")
    P("  Set L1 = f2d.CreateLine(x0, y0, x1, y0)  ' bottom")
    P("  Set L2 = f2d.CreateLine(x1, y0, x1, y1)  ' right")
    P("  Set L3 = f2d.CreateLine(x1, y1, x0, y1)  ' top")
    P("  Set L4 = f2d.CreateLine(x0, y1, x0, y0)  ' left")
    P("")
    P("  skRect.CloseEdition")
    P("  part.Update")
    P("")
    P("  ' =======================")
    P("  ' 2) PAD from that sketch")
    P("  ' =======================")
    P("  Dim pad1")
    P("  Set pad1 = shapeFactory.AddNewPad(skRect, thk)")
    P("  part.Update")
    P("")
 
    P("  ' =======================")
    P("  ' 3) For each hole: circle sketch + pocket cut")
    P("  ' =======================")
    P("  Dim i")
    P("  For i = 0 To UBound(holes, 1)")
    P("    Dim skHole, f2dHole, circle1, rad, hx, hy, dia")
    P("    hx  = CDbl(holes(i,0))")
    P("    hy  = CDbl(holes(i,1))")
    P("    dia = CDbl(holes(i,2))")
    P("    rad = dia / 2")
    P("")
    P("    Set skHole = sketches1.Add(XY)")
    P("    Set f2dHole = skHole.OpenEdition()")
    P("    Set circle1 = f2dHole.CreateCircle(hx, hy, rad)")
    P("    skHole.CloseEdition")
    P("    part.Update")
    P("")
    P("    Dim pocket1, depth")
    P("    depth = thk ' cut through")
    P("    Set pocket1 = shapeFactory.AddNewPocket(skHole, depth)")
    P("    part.Update")
    P("  Next")
    P("")
    P("  ' Optional save:")
    P("  ' partDocument.SaveAs \"C:\\Users\\Public\\Documents\\AI_Generated_Part.CATPart\"")
    P("  ' part.Update")
    P("")
    P("End Sub")
 
    return "\n".join(lines)
 
def main():
    ft, src = load_feature_tree()
    baseL, baseW, thickness, holes = extract_dims_and_features(ft)
 
    # safety defaults if validator missed something
    if not baseL or not baseW:
        print("⚠️  Missing rectangle dims in feature tree; using defaults 100x50.")
        baseL = baseL or 100.0
        baseW = baseW or 50.0
    if not thickness:
        print("⚠️  Missing thickness in feature tree; using default 10.")
        thickness = thickness or 10.0
 
    script = render_catscript(baseL, baseW, thickness, holes)
 
    os.makedirs("sample_output", exist_ok=True)
    out_path = "sample_output/generated.CATScript"
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(script)
 
    print("✅ CATScript generated:", out_path)
    print("   Base:", baseL, "x", baseW, "mm | thk:", thickness, "mm")
    print("   Holes:", holes if holes else "none")
 
if __name__ == "__main__":
    main()
 